from flask import Flask
from data import db_session
from data.users import User
from data.jobs import Jobs

app = Flask(__name__)
app.config['SECRET_KEY'] = 'moo'


def main():
    db_session.global_init('db/marsiane.db')
    db_sess = db_session.create_session()

    capitan = User()
    capitan.surname = "Scott"
    capitan.name = "Ridley"
    capitan.age = 21
    capitan.position = "captain"
    capitan.speciality = "research engineer"
    capitan.address = "module_1"
    capitan.email = "scott_chief@mars.org"

    db_sess.add(capitan)

    user1 = User()
    user1.surname = "Vladimur"
    user1.name = "Mewotin"
    user1.age = 1337
    user1.position = "ученый"
    user1.speciality = "cat"
    user1.address = "module_1"
    user1.email = "progamer@mars.org"

    db_sess.add(user1)

    user2 = User()
    user2.surname = "Тайлер"
    user2.name = "Дерден"
    user2.age = 228
    user2.position = "Мотиватор"
    user2.speciality = "Продавец мыла"
    user2.address = "Бойцовский клуп"
    user2.email = "123tyler666@mars.org"

    db_sess.add(user2)

    user3 = User()
    user3.surname = "Мизулин"
    user3.name = "SHAMAN"
    user3.age = 32
    user3.position = "Я РУССКИЙ"
    user3.speciality = "певец"
    user3.address = "феско холл"
    user3.email = "pr@shamanofficial.ru"

    db_sess.add(user3)

    db_sess.commit()

    app.run()


if __name__ == '__main__':
    main()

